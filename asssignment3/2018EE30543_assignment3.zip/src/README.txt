Double Hashing 

pair<K extends Comparable<pair<A,B>,T> 
	this contains key of type K and an obj of type T and int type
	constructor  initialise these values
	method changeobj(obj) replace the obj
	method chtype change the type int to 1 (marked as deleted)
	method compareTO compare keys according to need
	method equals return true if two keys are true


MyHashTable<K,T> implements interface MyHashTable_<K,T>
     the class contains the arrary of type pair<K,T> of size given in constructor;
	insert(K key,T obj)   Complaxcity= O(1/1-x)==O(1) where x= load factor;
                                           x=table size/no of keys inserted;
	Complaxcity proof

	As this method first find index using key and then insert obj at that place, and if place is already occupied then it calculate 
	index untill place is empty, then it put obj at that place .Since a finit no of steps are taken to insert obj thus Complaxcity is O(1/1-x).

		 find index using hash function djb2 untill the obj at that index (which is calculated according to hash function)
	in array is not null or object is of deleted type and return number of times new index was formed.

	update(K key,T obj)   Complaxcity= O(1/1-x) where x= load factor;

	index calculater using key given untill the obj at that index is same as 
	key of obj at that place then obj is replaced. Whenever obj at index is of type deleted then 
	whithout comparing next index is calculated.No of times index was calculater
	is returned.If key is not found than -1 is return.
	
	delete(K key)   Complaxcity= O(1/1-x) where x= load factor;

	index calculated using given key untill the obj at that index is same as 
	key of obj at that place then type of that obj is changed to deleted.
	Deleted type obj allow to search further.No of times index was calculater
	is returned.If key is not found than -1 is return.

	contains(K key)  Complaxcity= O(1/1-x) where x= load factor;

	indez calculated using given key untill the obj at that index is same as 
	key of the obj at that place ,then returned true,else if reached to index
	where obj is null then returned false.
	

	get(K Key) Complaxcity= O(1/1-x) where x= load factor;

	using same algorithum as above method obj with key=key is found an than returned obj.
	If not found NotFoundException is thrown.

	address(k key) Complaxcity= O(1/1-x) where x= load factor;

	using same algorithum as above method obj with key=key is found an than returned 
	index at which it is found.
	If not found NotFoundException is thrown.

Chain hashing 

node<K,T> 
	contains node left ,node right
	method putl() replace the left node
	methid putr() replace the right node

BS<K,T> 
	contains node named root and a counter
	method insert(K key,T Obj) assign counter value as 0 and then call ins() 
	with root and then return counter.
	
	method ins(node<K,T> r,K key,T obj) return node with inserted new node(with key and obj)
	in node r; counter is increased for every node touched;

	method update callsassign counter value as 0 and then call upd() 
	with root and then return counter

	method upd(node<K,T> r,K key) return node with updated node(with key and obj)
	in node r; counter is increased for every node touched;

	method delete callsassign counter value as 0 and then call del() 
	with root and then return counter

	method del(node<K,T> r,K key) return node with deleted node(with key and obj)
	in node r; counter is increased for every node touched;
	
	method contains(key) return true if key is found in the tree.

BST<K,T> 
	contains int size and array of BS<K,T> table[]
	
	insert(K key,T obj)  Complaxcity =O(log(n)) 

	As this method it is called recursively to itself and each time the places where it has to be inserted is halfed, thus Complaxcity is O(log(n))
		this method first find index according to given key 
	if(table[index]==null) new BS is make and insert function is called ans 
	return value is returned;
	else inserted in the bst(BS type obj at index place).

	update(K key,T obj) Complaxcity=O(log(n))
		this method first find index according to given key 
	if(table[index]==null) return -1
	else updated in the bst(BS type obj at index place).

	delete(K key,T obj) Complaxcity=O(log(n))
		this method first find index according to given key 
	if(table[index]==null) return -1
	else return table[index].delete(key)

	contains(K key)  Complaxcity =O(log(n))
		this method first find index according to given key 
	if(table[index]==null) return false
	else returned table[index].contains(key)

	get(K key) Complaxcity =O(log(n))
		if key not found at the BS at index then NotFoundException is thrown
	else object of the found node is returned.

	address(K key) Complaxcity =O(log(n))
		if key not found at the BS at index then NotFoundException is thrown
	else String with path followed is returned;

Student implements Student_interface
	contains fname, lname, hostel, departement, cgpa.
	methods are there to return these.

NotFoundException extends Exception
	it print "E" when error is catched by caller.

Assignment3 
	have main method, args are taken, hashtable is made of type as stated in args.
	then reading the file one by one respective functions are called and output is printed.








	
	
	 
	