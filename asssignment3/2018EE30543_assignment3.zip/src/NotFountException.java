
class NotFoundException extends Exception {
	

	NotFoundException(){
		
	}
}